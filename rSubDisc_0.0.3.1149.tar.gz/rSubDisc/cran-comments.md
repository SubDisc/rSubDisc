## R CMD check results
There were no ERRORs. 

There was x WARNINGs:

There was x NOTEs:

