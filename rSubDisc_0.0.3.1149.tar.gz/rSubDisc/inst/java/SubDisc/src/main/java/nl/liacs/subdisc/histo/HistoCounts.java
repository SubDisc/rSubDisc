package nl.liacs.subdisc.histo;

import java.util.Arrays;

public final class HistoCounts
{
//	private final double[] x;
//	private final double[] y;
//
//	HistoCounts(double[] data)
//	{
//		// copy - data remains unchanged
//		double[] out = Arrays.copyOf(data, data.length);
//
//		// 2-stage process, Map uses a lot of memory
//		x = A.uniqueSorted(out);
//		y = A.getCounts(data, x);
//	}
//
//	// assumes every value in data is in this.x
//	final double[] getCounts(double[] data)
//	{
//		return A.getCounts(data, x);
//	}
}
