package nl.liacs.subdisc;

public class DataCube
{
	protected int itsSize;

	public int getSize() { return itsSize; }
	public void setSize(int itsSize) { this.itsSize = itsSize; }
}
