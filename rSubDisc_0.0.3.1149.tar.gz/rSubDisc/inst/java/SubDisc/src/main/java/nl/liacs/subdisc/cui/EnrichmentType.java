package nl.liacs.subdisc.cui;

public enum EnrichmentType
{
	CUI, GO, CUSTOM;
}
