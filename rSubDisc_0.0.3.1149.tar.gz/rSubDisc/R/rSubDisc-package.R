#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @import rJava
## usethis namespace: end
NULL
