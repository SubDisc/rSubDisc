library(testthat)
library(rSubDisc)

test_check("rSubDisc")
