# Changelog

## [0.0.3.1104]
- Changed Cortana to SubDisc library (subdisc-lib)
- Updated SubDisc library to version 2.1104
- Function use string for options (instead of function call)
- src can now be a data.frame or a tibble
- targetColumn can be the name of the column
- Removed null values and replaced by default where possible

## [0.0.2.1025]
- Changed to return to be a tibble

## [0.0.1-alpha]
- Basic functionality to call Cortana/SubDisc
